#include "CoreUtilities.h"

View CU::view;
Input CU::input;
SharedResources CU::shared;
EntityManager CU::entityMan;
double CU::dt = 0.0;
float CU::fps = 0.f;